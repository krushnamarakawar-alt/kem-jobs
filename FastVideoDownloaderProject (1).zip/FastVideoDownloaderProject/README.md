# Fast Video Downloader (Android Studio)

Ye demo project direct video links (jinhe download ki permission ho) ko Android DownloadManager se download karta hai.

Open in Android Studio:
1. New Project (Empty Activity)
2. Package: com.example.fastvideodownloader
3. In files ko replace karo.
